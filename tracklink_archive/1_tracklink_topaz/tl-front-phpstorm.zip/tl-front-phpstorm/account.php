<?php
// Security: in account, n/a workcenter
// Purpose: view and edit account info

require_once 'inc/Tracklink.php';
?>

    <!-- Modals here -->

    <div class="page-wrapper with-navbar with-sidebar">
        <div class="sticky-alerts"></div>

        <nav class="navbar">
        </nav>

        <div class="sidebar">
        </div>

        <div class="content-wrapper">
        </div>

    </div>

<?php
echo getFooter();