<?php
session_start();

header('Location: /feed.php');
exit;